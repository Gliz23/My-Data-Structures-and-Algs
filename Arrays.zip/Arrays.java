

public class Arrays {
    public void main(String[] args) {
        Array numbers = new Array(3);
        numbers.print();
    }
    
    public class Array{
        private int[] items;
        private int[] count;
        public Array(int length){

            items = new int[length];
        }

        public void print() {
            for (int i = 0; i < items.length; i++)
                System.out.println(items[i]);
        }
    }
}
