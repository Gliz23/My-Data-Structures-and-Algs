public class Array{
    private int[] items;
    private int count;
    public Array(int length){
        items = new int[length];
    }

    public void insert(int  item) {
        // Check if the array is full.
        if (items.length==count) {
        // Create a new array twice the length
            int [] newItems = new int [2*count];

            // Copy all existing items.
            for (int i=0; i< count; i++)
                newItems[i] = items[i];

            //Set new items to items.
            items = newItems;
        }

        items[count++] = item;
    }
    public void print() {
        for (int i = 0; i < count; i++) {
            System.out.println(items[i]);
        }
    }

}